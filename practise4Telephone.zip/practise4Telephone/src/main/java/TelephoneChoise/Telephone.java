package TelephoneChoise;

public class Telephone {
    private String model;
    private String serialNumber;
    private String color;
    private boolean isMobile;

    Telephone(String model, String serialNumber, String color, boolean isMobile) {
        this.model = model;
        this.serialNumber = serialNumber;
        this.color = color;
        this.isMobile = isMobile;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    @Override
    public String toString() {
        return model + ", " + serialNumber + ", " + color + ", " + (isMobile ? "Смартфон" : "Кнопочный телефон");
    }
}
