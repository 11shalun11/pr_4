package TelephoneChoise;

import java.util.ArrayList;

public class TelephoneList {
    private ArrayList<Telephone> telephoneList;

    TelephoneList() {
        telephoneList = new ArrayList<>();
        telephoneList.add(new Telephone("Nokia 3310", "123", "Черный", false));
        telephoneList.add(new Telephone("iPhone X", "456", "Серебряный", true));
        telephoneList.add(new Telephone("Samsung Galaxy S10", "789", "Синий", true));
    }

    void addTelephone(String model, String serialNumber, String color, boolean isMobile) {
        for (Telephone telephone : telephoneList) {
            if (telephone.getSerialNumber().equals(serialNumber)) {
                System.out.println("Ошибка! Этот серийный номер уже присутствует в списке.");
                return;
            }
        }
        Telephone newTelephone = new Telephone(model, serialNumber, color, isMobile);
        telephoneList.add(newTelephone);
        System.out.println("Ваша модель была добавлена в список");
    }

    void removeTelephone(String serialNumber) {
        int index = -1;
        for (int i = 0; i < telephoneList.size(); i++) {
            if (telephoneList.get(i).getSerialNumber().equals(serialNumber)) {
                index = i;
                break;
            }
        }
        if (index >= 0) {
            telephoneList.remove(index);
            System.out.println("Ваша модель была удалена из списка");
        } else {
            System.out.println("Этот серийный номер отсутствует в списке");
        }
    }

    void removeallTelephones() {
        telephoneList.clear();
        System.out.println("Все модели были удалены из списка");
    }

    void printTelephoneList() {
        System.out.println("Модель\tСерийный номер\tЦвет\tТип");
        for (Telephone telephone : telephoneList) {
            System.out.println(telephone);
        }
    }
}

