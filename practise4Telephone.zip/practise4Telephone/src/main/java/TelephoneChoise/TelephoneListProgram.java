package TelephoneChoise;
import java.util.Scanner;

public class TelephoneListProgram {
    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Практика-4, Вариант 2, Шалунова А.С.");
        TelephoneList telephoneList = new TelephoneList();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Добавить модель");
            System.out.println("2. Удалить модель");
            System.out.println("3. Удалить все модели");
            System.out.println("4. Вывести список моделей");
            System.out.println("5. Выход");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Введите модель:");
                    String model = scanner.next();
                    System.out.println("Введите серийный номер:");
                    String serialNumber = scanner.next();
                    System.out.println("Введите цвет:");
                    String color = scanner.next();
                    System.out.println("Введите 1 для смартфона и 0 для кнопочного телефона:");
                    boolean isMobile = scanner.nextInt() == 1;
                    telephoneList.addTelephone(model, serialNumber, color, isMobile);
                    break;

                case 2:
                    System.out.println("Введите серийный номер:");
                    serialNumber = scanner.next();
                    telephoneList.removeTelephone(serialNumber);
                    break;
                case 3:
                    telephoneList.removeallTelephones();
                    break;

                case 4:
                    telephoneList.printTelephoneList();
                    break;

                case 5:
                    System.exit(0);

                default:
                    System.out.println("Неверный вариант. Попробуйте еще раз.");
                    break;
            }
        }
    }
}

